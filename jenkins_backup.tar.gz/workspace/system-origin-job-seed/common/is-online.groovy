import jenkins.model.Jenkins
