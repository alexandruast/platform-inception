import jenkins.model.Jenkins
println "Jenkins is Ready!"
